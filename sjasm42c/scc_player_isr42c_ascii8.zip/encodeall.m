close all

x = dir('wav\*.wav');
nfiles = size(x,1);

snr_new = zeros(nfiles,1);
%snr_old = zeros(nfiles,1);

for i=1:nfiles
    disp (x(i).name);
%    snr_old(i) = scc(3.0,x(i).name,i-1);
    snr_new(i) = scc_new(3.0,['wav\' x(i).name],i-1);
end

for i=1:nfiles
    disp (x(i).name);
    disp (snr_new(i))
%    disp (snr_old(i))
end
    
fid = fopen('SfxTable.asm','wb');
for i=1:nfiles
	s = num2str(i-1);
    fwrite(fid,['         dw     06000h + (s' s '_START & 01FFFH)' 13 10],'char');
    fwrite(fid,['         db     s' s '_START/02000h-2' 13 10],'char');
    fwrite(fid,['         dw     (s' s '_END - s' s '_START+127)/128' 13 10],'char');
    fwrite(fid,['    ' 13 10],'char');
end
fclose(fid);


fid = fopen('DataTable.asm','wb');
for i=1:nfiles
	s = num2str(i-1);
    fwrite(fid,['s' s '_START:' 13 10],'char');
    fwrite(fid,['         incbin data' s '.bin ' 13 10],'char');
    fwrite(fid,['s' s '_END:' 13 10],'char');
end
fclose(fid);


delete data*.mat ;
movefile('data*.bin','.\bin');

!.\sjasm42c\sjasm -i.\bin new_sccpoliplayer.asm
