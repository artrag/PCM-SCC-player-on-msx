function [out,err] = clamp(in)
out = max(min(in ,127*256),-128*256);
err = -(in - out);
err = max(min(err ,127*256),-128*256)/4.6;
end