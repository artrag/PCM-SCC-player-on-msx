function [out] = scc(in,name,num)

Fr = 60/1.001;
fc = ((455/2) * (525/2) * (60/1.001));

[Y,Fs,NBITS,OPTS]=wavread(name);

Frs = fix(4*32*Fr);
G = gcd(Fs,Frs);
P = Frs/G;
Q = Fs/G;

    % convert to mono
if (size(Y,2)>1)
    Y1 = Y(:,1)+Y(:,2);
    Y = Y1;
end

Y = resample(Y,P,Q);
Y = 2.0*Y/(max(Y)-min(Y));
Y = Y - (max(Y)+min(Y))/2;

%wavwrite(Y,Frs,16,'tst_7.6KHz.wav');

YY = Y*256*in*127;
Y = double( YY );

l = size(Y,1);

%l / Frs;

Z = zeros(4*fix(l/4)+4,1);
Z(1:(l)) = Y;
clear Y
Y = Z;

Z = zeros(4*fix(l/4)+4,1);
Z(1:(l)) = YY;
clear YY
YY = Z;

ph1 = Y(1:4:end);
ph2 = Y(2:4:end);
ph3 = Y(3:4:end);
ph4 = Y(4:4:end);

ch1 = int16(zeros(size(ph1)));
ch2 = ch1;
ch3 = ch2;
ch4 = ch3;

[ch1(1),err] = clamp(double(ph1(1))                                                         );
[ch2(1),err] = clamp(double(ph2(1)) - double(ch1(1))                                   + err);
[ch3(1),err] = clamp(double(ph3(1)) - double(ch1(1)) - double(ch2(1))                  + err);
[ch4(1),err] = clamp(double(ph4(1)) - double(ch1(1)) - double(ch2(1)) - double(ch3(1)) + err);

for i=2:size(Y)/4
    [ch1(i),err] = clamp(double(ph1(i))-double(ch2(i-1))-double(ch3(i-1))-double(ch4(i-1)) + err);
    [ch2(i),err] = clamp(double(ph2(i))-double(ch1(i))  -double(ch3(i-1))-double(ch4(i-1)) + err);
    [ch3(i),err] = clamp(double(ph3(i))-double(ch1(i))  -double(ch2(i))  -double(ch4(i-1)) + err);
    [ch4(i),err] = clamp(double(ph4(i))-double(ch1(i))  -double(ch2(i))  -double(ch3(i))   + err);
end


C1 = kron(double(ch1),[1;1;1;1]);
C2 = kron(double(ch2),[1;1;1;1]);
C3 = kron(double(ch3),[1;1;1;1]);
C4 = kron(double(ch4),[1;1;1;1]);

Z = C1 + [0; C2(1:end-1)] + [0;0; C3(1:end-2)] + [0;0;0; C4(1:end-3)];

%close all
figure;
plot (1:size(Y,1),Y,'b',1:size(Z,1),Z,'r')
title('Blue: original, Red: replayer')
figure;
plot(Z-YY)
title('Error')

disp(' ');

out = convert2db(sqrt(norm(double(YY))/norm(double(Z-YY)))); 
disp(['snr (db)= ', num2str(out)]);
disp(['Max err= ', num2str(max(abs(double(Z-YY))))]);

% 
% 
% for i=1:32:(size(ch1,1)-32)
%     for j=1:32
%         dst(4*(i-1) +  0 + j) = int8( double(ch1(i-1+j))/256 );
%         dst(4*(i-1) + 32 + j) = int8( double(ch2(i-1+j))/256 );
%         dst(4*(i-1) + 64 + j) = int8( double(ch3(i-1+j))/256 );
%         dst(4*(i-1) + 96 + j) = int8( double(ch4(i-1+j))/256 );
%     end
% end
% 
% 
% fid = fopen('data.bin','wb');
% fwrite(fid,dst,'int8');
% fclose(fid);

fname = [ 'data' num2str(num) '.bin'];
fid = fopen(fname,'wb');
for i=1:32:(size(ch1,1)-32)
    fwrite(fid,int8(double(ch1(i:(i+31)))/256),'int8');
    fwrite(fid,int8(double(ch2(i:(i+31)))/256),'int8');
    fwrite(fid,int8(double(ch3(i:(i+31)))/256),'int8');
    fwrite(fid,int8(double(ch4(i:(i+31)))/256),'int8');    
end
fclose(fid);


ft = Fr*32;
P = fix(fc/ft-1);

disp(['Ideal period of the SCC waves (hex) ',dec2hex(P) ]);

disp(['Offset in cycles among channels ',num2str(fc/(Frs))]);

fname = [ 'data' num2str(num) '.mat'];
save(fname);


